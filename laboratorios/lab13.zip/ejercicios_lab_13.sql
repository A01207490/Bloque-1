/*SELECT columnas 
FROM tablas
WHERE se especifica las condiciones del 
demas las condiciones de selecion sobre campos
*/

/* Descripción de los materiales que fueron entregados al proyecto vamos mexico en el año 2010
 */

SELECT M.Descripcion --Especifica el campo si es que existe en mas de una relacion, el error si no se hace es la columna ambigua
FROM Materiales AS M, Proyectos AS P, Entregan AS E
WHERE M.clave = E.clave
AND E.numero = P.numero
AND P.denominacion = 'Vamos México'
--Primera versión
AND E.entregan >= '01/01/2010'
AND E.entregan <= '31/10/2010'
--Segunda versión, el between es más legible
AND E.entregan BETWEEN '01/01/2010' AND '31/10/2010'

--El lenguaje no es sensible a las mayúsculas y minúsculas de las columnas
--No se usan comillas dobles en SQL solo sencillas
--Las fechas varian mucho de gestor a gestor
--Se pueden utilizar parentesis 

AND (E.entregan BETWEEN '01/01/2010' AND '31/10/2010')
OR  (E.entregan BETWEEN '01/01/2008' AND '31/10/2008')

/*Por cada proyecto mostrar el total de unidades entregadas solo si son para aquellas proyetcos donde se entregagaron en total
 * mas de 10 unidades
*/

SELECT P.denominacion, SUM(E.cantidad) AS 'Total de unidades entregadas' --Casi siempre se usa el group by con funciones agregadas
FROM Proyectos AS P, Entregan AS E
WHERE P.numero = E.numero
GROUP BY p.denominacion 
--HAVING (no es para agrupar) es opcional y siempre van ahí, condiciones sobre funciones agregadas having va al final, es mejor no usar el alias para evitar errores.
HAVING BY 'Total  de unidades entregadas' > 10 
ORDER BY 'Total de unidades entregadas' ASC 


--HAVING (no es para agrupar)
--Con llaves compuestas se igualan todas las llaves entre si con AND
-- El group by las n columna sque no tiene la funciona agregada


