/*
 * INSERT INTO Materiales values(1000, 'xxx', 1000)
 * Delete from Materiales where Clave = 1000 and Costo = 1000
 * ALTER TABLE Materiales add constraint llaveMateriales PRIMARY KEY (Clave)
 * INSERT into Materiales values(1000, 'xxx', 1000)
 * sp_helpconstraint materiales
 * ALTER TABLE Materiales add constraint llaveMateriales PRIMARY KEY (Clave);
 * ALTER TABLE Proveedores add constraint llaveProveedores PRIMARY KEY (RFC);
 * ALTER TABLE Proyectos add constraint llaveProyectos PRIMARY KEY (Numero)
 * ALTER TABLE Entregan add constraint llaveEntregan PRIMARY KEY (Numero, RFC, Clave, Fecha)
 * INSERT INTO entregan values (0, 'xxx', 0, '1-jan-02', 0) 
 * Delete from Entregan where Clave = 0
 * ALTER TABLE entregan add constraint cfentreganclave foreign key (clave) references materiales(clave)
 * ALTER TABLE entregan add constraint cfentreganrfc foreign key (rfc) references proveedores(rfc)
 * ALTER TABLE entregan add constraint cfentregannumero foreign key (numero) references proyectos(numero)
 * sp_helpconstraint entregan
 * INSERT INTO entregan values (1000, 'AAAA800101', 5000, GETDATE(), 0)
 * Delete from entregan where Cantidad = 0
 * ALTER TABLE entregan add constraint cantidad check (cantidad > 0) ;
 */


