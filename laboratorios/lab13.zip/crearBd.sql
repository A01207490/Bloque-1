IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Materiales')
   DROP TABLE Materiales;
   
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Proveedores')
   DROP TABLE Proveedores;
 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Proyectos')
   DROP TABLE Proyectos;
   
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Entregan')
   DROP TABLE Entregan;
  
CREATE TABLE Materiales
(
  Clave numeric(5) not null, 
  Descripcion varchar(50),
  Costo numeric(8,2)
);
CREATE TABLE Proveedores
(
  RFC char(13) not null,
  RazonSocial varchar(50)
);
CREATE TABLE Proyectos
(
  Numero numeric(5) not null,
  Denominacion varchar(50)
);
CREATE TABLE Entregan
(
  Clave numeric(5) not null,
  RFC char(13) not null,
  Numero numeric(5) not null,
  Fecha datetime not null,
  Cantidad numeric (8,2)
);

BULK INSERT Materiales
FROM '/home/albertoplata/Documents/bloque1/lab13/materiales.csv'
WITH
(
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
);
;
BULK INSERT Proveedores 
FROM '/home/albertoplata/Documents/bloque1/lab13/proveedores.csv'
WITH
(
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)     
BULK INSERT Proyectos
FROM '/home/albertoplata/Documents/bloque1/lab13/proyectos.csv'
WITH
(     
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)
SET DATEFORMAT dmy;
BULK INSERT Entregan
FROM '/home/albertoplata/Documents/bloque1/lab13/entregan.csv'
WITH
(
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)
