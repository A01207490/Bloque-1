BULK INSERT Materiales
   FROM '/home/albertoplata/Desktop/lab06/materiales.csv'
   WITH
      (
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )