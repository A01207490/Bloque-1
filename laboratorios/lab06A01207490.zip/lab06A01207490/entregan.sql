SET DATEFORMAT dmy;
BULK INSERT Entregan
   FROM '/home/albertoplata/Desktop/lab06/entregan.csv'
   WITH
      (
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )