BULK INSERT Proyectos
   FROM '/home/albertoplata/Desktop/lab06/proyectos.csv'
   WITH
      (
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )