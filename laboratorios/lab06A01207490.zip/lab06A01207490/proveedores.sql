BULK INSERT Provedores
   FROM '/home/albertoplata/Desktop/lab06/provedores.csv'
   WITH
      (
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )